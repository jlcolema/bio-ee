All files are in .csv format. (Can be opened with Excel)

Figure 1 (e): 
back-gate sweeps with (a-2) and without PVA (a-1) of same device. Aspect ratio 2.5/3. Units: Ohms

Figure 2 (a):
IV sweep of a 2.5um device. Units:mA/um

Figure 2 (b):
IV sweep of a 350nm device. Units:A/um

Figure 2 (d):
IV sweep (pulsed) of a 350nm device. Units:A/um

pulse_iv_130nm
IV sweep (pulsed) of a 130nm device. Width: 2.3um Units:Amps

pulse_iv_130nm
IV sweep (pulsed) of a 474nm device. Width: 2.3um Units:Amps