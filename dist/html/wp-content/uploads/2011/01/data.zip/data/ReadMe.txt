This folder contains all data used to prepare this manuscript. Details as below:

IV.txt: First column is source-drain voltage (in V), remaining 4 columns are drain current in A.

linear transport.txt: Resistance (in Ohms) versus gate voltage measured at 1 mV source-drain bias.

high_frequ resp.txt: Current gain (dB) and Unilateral power gain (dB) versus frequency (GHz)

channel length.txt: f_T and f_max values in GHz versus channel length (nm)

fmax_bias.txt:f_max (GHz) versus DC bias. Columns are different source-drain voltage, rows are gate voltage from 0V to 1.5V in 0.1V steps.

ft_bias.txt:f_T (GHz) versus DC bias. Columns are different source-drain voltage, rows are gate voltage from 0V to 1.5V in 0.1V steps.

S_parameter.s2p:S-parameters (S11 S12 S21 S22) at a single bias point after de-embedding


